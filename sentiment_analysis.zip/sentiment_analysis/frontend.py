import streamlit as st
import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import base64
import io
from st_aggrid import AgGrid

st.set_page_config(layout="wide")
st.sidebar.title("Sentiment Analyzer")

# ---------------- API URLs ----------------
CLASSIFY_API = "http://127.0.0.1:8000/classify_file"
ANALYZE_API = "http://127.0.0.1:8500/analyze"

# ---------------- API Key input ----------------
api_key = st.sidebar.text_input(
    "Enter API Key",
    type="password",
    placeholder="Enter your API key here"
)

df = None  # Initialize DataFrame

if not api_key:
    st.sidebar.warning("🔑 Please enter the API key to proceed.")
else:
    # Test the API key by sending a dummy request
    try:
        response = requests.post(
            CLASSIFY_API,
            files={},  # no file yet
            headers={"x-api-key": api_key},
            timeout=5
        )

        if response.status_code == 401:
            st.sidebar.error("❌ Invalid API key. Please try again.")
        else:
            # API key is valid, show uploader
            uploaded_file = st.sidebar.file_uploader("Upload CSV", type=["csv"])
            if uploaded_file is not None:
                files = {"file": (uploaded_file.name, uploaded_file, "text/csv")}
                headers = {"x-api-key": api_key}

                response = requests.post(CLASSIFY_API, files=files, headers=headers)
                if response.status_code == 200:
                    st.success("CSV classified successfully!")
                    df = pd.read_csv(io.BytesIO(response.content))
                    st.write("### Preview of Labeled CSV")
                    AgGrid(df)
                else:
                    st.error(f"Error: {response.status_code} - {response.text}")
    except requests.exceptions.RequestException as e:
        st.sidebar.error(f"❌ Unable to verify API key: {e}")

# ---------------- Process Analysis ----------------
if df is not None:
    # Download labeled CSV
    st.download_button(
        label="Download Labeled CSV",
        data=df.to_csv(index=False).encode("utf-8"),
        file_name="labeled_data.csv",
        mime="text/csv"
    )

    # Clause filter
    if "Clause" in df.columns:
        clauses = sorted(df["Clause"].dropna().unique().tolist())
        clauses.insert(0, "Overall")
    else:
        clauses = ["Overall"]
    selected_clause = st.sidebar.selectbox("Choose Clause to Analyze", clauses)

    # Label filter
    if "Label" in df.columns:
        labels = sorted(df["Label"].dropna().unique().tolist())
        labels.insert(0, "Overall")
    else:
        labels = ["Overall"]
    selected_label = st.sidebar.selectbox("Choose Label to Analyze", labels)

    # Run Analysis
    if st.sidebar.button("Run Analysis"):
        with st.spinner("Analyzing..."):
            # Filter DataFrame
            df_filtered = df.copy()
            if selected_clause != "Overall":
                df_filtered = df_filtered[df_filtered["Clause"] == selected_clause]
            if selected_label != "Overall":
                df_filtered = df_filtered[df_filtered["Label"] == selected_label]

            if df_filtered.empty:
                st.warning("No data found for the selected Clause/Label.")
                st.stop()

            # Convert filtered DataFrame to CSV bytes
            csv_bytes = df_filtered.to_csv(index=False).encode("utf-8")
            files = {"file": ("filtered.csv", io.BytesIO(csv_bytes), "text/csv")}

            try:
                resp = requests.post(ANALYZE_API, files=files, headers={"x-api-key": api_key})
                resp.raise_for_status()
                data = resp.json()
            except Exception as e:
                st.error(f"API Error: {e}")
                st.stop()

        st.success("Analysis Complete!")

        # ---------------- Top Statistics ----------------
        st.title("📊 Top Statistics")
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Comments", data.get("total_comments", 0))
        col2.metric("Unique Clause", data.get("unique_clause", 0))
        col3.metric("Avg. Word Count", round(data.get("avg_word_count", 0), 2))

        # ---------------- Sentiment Distribution ----------------
        if "sentiment_counts" in data and data["sentiment_counts"]:
            st.title("📈 Sentiment Distribution")
            sentiment_df = pd.DataFrame(list(data["sentiment_counts"].items()), columns=["Sentiment", "Count"])
            col1, col2 = st.columns(2)
            with col1:
                fig, ax = plt.subplots()
                ax.bar(sentiment_df["Sentiment"], sentiment_df["Count"], color="teal")
                plt.xticks(rotation=30)
                st.pyplot(fig)
            with col2:
                fig, ax = plt.subplots()
                ax.pie(sentiment_df["Count"], labels=sentiment_df["Sentiment"], autopct="%0.1f%%")
                ax.axis("equal")
                st.pyplot(fig)
        else:
            st.warning("⚠️ No sentiment distribution data available.")

        # ---------------- Word Cloud ----------------
        if data.get("wordcloud_base64"):
            st.title("☁️ Word Cloud")
            img_b64 = data["wordcloud_base64"]
            img = base64.b64decode(img_b64)
            st.image(img, use_container_width=True)

        # ---------------- Most Common Words ----------------
        if "top_words" in data:
            st.title("🔠 Most Common Words")
            top_words = pd.DataFrame(data["top_words"], columns=["Word", "Frequency"])
            fig, ax = plt.subplots()
            ax.barh(top_words["Word"].head(15), top_words["Frequency"].head(15), color="orange")
            ax.invert_yaxis()
            plt.xticks(rotation=30)
            st.pyplot(fig)

        # ---------------- N-Grams ----------------
        if "top_bigrams" in data:
            st.title("📌 Top Bigrams")
            bigram_df = pd.DataFrame(data["top_bigrams"], columns=["Bigram", "Frequency"])
            fig, ax = plt.subplots()
            ax.barh(bigram_df["Bigram"].head(10), bigram_df["Frequency"].head(10), color="blue")
            ax.invert_yaxis()
            st.pyplot(fig)

        if "top_trigrams" in data:
            st.title("📌 Top Trigrams")
            trigram_df = pd.DataFrame(data["top_trigrams"], columns=["Trigram", "Frequency"])
            fig, ax = plt.subplots()
            ax.barh(trigram_df["Trigram"].head(10), trigram_df["Frequency"].head(10), color="purple")
            ax.invert_yaxis()
            st.pyplot(fig)

        # ---------------- Horizontal Grouped Bar Chart ----------------
        if "clause_sentiment" in data and data["clause_sentiment"]:
            clause_data = data["clause_sentiment"]

            if isinstance(clause_data, dict) and len(clause_data) > 0:
                st.title("📊 Sentiment % by Clause")

                clause_df = pd.DataFrame(clause_data).T
                clause_df = clause_df[["Positive", "Neutral", "Negative"]]

                n_clauses = len(clause_df)
                index = np.arange(n_clauses)
                bar_width = 0.25

                fig, ax = plt.subplots(figsize=(10, max(4, n_clauses*0.5)))

                ax.barh(index - bar_width, clause_df["Positive"], height=bar_width, label="Positive", color="green")
                ax.barh(index, clause_df["Neutral"], height=bar_width, label="Neutral", color="grey")
                ax.barh(index + bar_width, clause_df["Negative"], height=bar_width, label="Negative", color="red")

                ax.set_yticks(index)
                ax.set_yticklabels(clause_df.index)
                ax.set_xlabel("Percentage (%)")
                ax.set_title("Sentiment Distribution per Clause")
                ax.legend()
                st.pyplot(fig)
            else:
                st.warning("⚠️ Clause sentiment data is empty. Please check your CSV.")
        else:
            st.warning("⚠️ Clause sentiment data not available for the chart.")
